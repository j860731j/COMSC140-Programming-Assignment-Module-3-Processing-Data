FileName="vaccinations.csv"
header=None

lst_PercentV=[]
lst_Zip=[]

with open(FileName,"r") as DataFile:
    for CurrentLine in DataFile:
        if (header==None):
            header=CurrentLine
            continue

        CurrentLine=CurrentLine.rstrip()
        CurrentLine=CurrentLine.split(',')

        if (CurrentLine[0] == "" or CurrentLine[8] == ""):
            continue

        PercentV=float(CurrentLine[8])
        Zip=int(CurrentLine[0])
        lst_PercentV.append(PercentV)
        lst_Zip.append(Zip)

p_max=max(lst_PercentV)
z_max=lst_Zip[lst_PercentV.index(p_max)]
p_min=min(lst_PercentV)
z_min=lst_Zip[lst_PercentV.index(p_min)]
p_avg=sum(lst_PercentV)/len(lst_PercentV)

print("ZIP with highest vaccination percentage:",z_max,"(","{:.2f}".format(p_max*100),"%)")
print("ZIP with lowest vaccination percentage:",z_min,"(","{:.2f}".format(p_min*100),"%)")
print("Average percentage across all ZIPs:","{:.2f}".format(p_avg*100),"%")